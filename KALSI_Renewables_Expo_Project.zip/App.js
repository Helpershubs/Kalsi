import React, {useState} from 'react';
import {SafeAreaView, View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Alert, StatusBar} from 'react-native';

const NAVY='#082B59', BLUE='#0B4D91', YELLOW='#F4C21B', BG='#F3F6FA', GREEN='#24833B';
const services=[
  ['☀️','On-grid Solar','Grid-connected solar systems for homes and businesses.'],
  ['🔋','Hybrid Solar','Solar with battery backup for essential loads.'],
  ['🔌','Off-grid Solar','Independent solar power solutions.'],
  ['🚜','Solar Pump Systems','Solar-powered agricultural water pumping.'],
  ['🏭','Commercial & Industrial','Solar EPC solutions for larger facilities.'],
  ['🛠️','AMC & Maintenance','Inspection, repair and ongoing maintenance.']
];
function Button({title,onPress,outline=false}) {
 return <TouchableOpacity onPress={onPress} style={[s.btn,outline&&s.outline]}><Text style={[s.btnText,outline&&{color:NAVY}]}>{title}</Text></TouchableOpacity>;
}
export default function App(){
 const [tab,setTab]=useState('Home');
 const [name,setName]=useState(''),[phone,setPhone]=useState(''),[city,setCity]=useState(''),[capacity,setCapacity]=useState(''),[kind,setKind]=useState('On-grid Solar');
 const [requests,setRequests]=useState([]);
 const [message,setMessage]=useState('');
 const [chat,setChat]=useState([]);
 const [admin,setAdmin]=useState(false);
 const submit=()=>{
  if(!name.trim()||!phone.trim()){Alert.alert('Details required','Please enter your name and phone number.');return;}
  setRequests([...requests,{name,phone,city,capacity,kind,status:'Enquiry received'}]);
  Alert.alert('Request saved','Your enquiry has been saved on this device. Connect a backend to receive it centrally.');
  setTab('Bookings');
 };
 const header=()=> <View style={s.header}><Text style={s.brand}>☀ KALSI</Text><Text style={s.subbrand}>RENEWABLES</Text><Text style={s.tag}>Powering a Sustainable Future</Text></View>;
 const card=(children)=> <View style={s.card}>{children}</View>;
 const home=()=> <ScrollView contentContainerStyle={s.content}>{header()}
  <View style={s.hero}><Text style={s.heroSmall}>CLEAN ENERGY. SMARTER TOMORROW.</Text><Text style={s.heroTitle}>Power your world with solar.</Text><Text style={s.heroText}>Explore solar solutions for your home, farm or business.</Text><Button title="Request a free consultation" onPress={()=>setTab('Quote')}/></View>
  <Text style={s.section}>Our Solar Solutions</Text>
  <View style={s.grid}>{services.map(([icon,title,desc])=><TouchableOpacity key={title} style={s.service} onPress={()=>{setKind(title);setTab('Quote')}}><Text style={s.icon}>{icon}</Text><Text style={s.serviceTitle}>{title}</Text><Text style={s.muted}>{desc}</Text></TouchableOpacity>)}</View>
  <View style={s.notice}><Text style={s.noticeTitle}>Need help choosing a system?</Text><Text style={s.muted}>Share your electricity needs and our team can help you plan the next step.</Text><Button title="Get a quotation" onPress={()=>setTab('Quote')}/></View>
  <Text style={s.foot}>KALSI Renewables · Solar EPC & services</Text>
 </ScrollView>;
 const quote=()=> <ScrollView contentContainerStyle={s.content}>{header()}<Text style={s.section}>Request a Solar Quotation</Text>{card(<>
  <Text style={s.label}>Full name *</Text><TextInput value={name} onChangeText={setName} placeholder="Enter your name" style={s.input}/>
  <Text style={s.label}>Mobile number *</Text><TextInput value={phone} onChangeText={setPhone} placeholder="Enter mobile number" keyboardType="phone-pad" style={s.input}/>
  <Text style={s.label}>City / location</Text><TextInput value={city} onChangeText={setCity} placeholder="Your city or village" style={s.input}/>
  <Text style={s.label}>System capacity (optional)</Text><TextInput value={capacity} onChangeText={setCapacity} placeholder="e.g. 5 kW" style={s.input}/>
  <Text style={s.label}>Solution required</Text>{services.map(([ic,t])=><TouchableOpacity key={t} onPress={()=>setKind(t)} style={[s.choice,kind===t&&s.choiceActive]}><Text style={{color:NAVY,fontWeight:'600'}}>{ic}  {t} {kind===t?'✓':''}</Text></TouchableOpacity>)}
  <Button title="Submit enquiry" onPress={submit}/>
  <Text style={s.muted}>Demo mode: requests are stored locally on this device only.</Text>
 </>)}</ScrollView>;
 const bookings=()=> <ScrollView contentContainerStyle={s.content}>{header()}<Text style={s.section}>My Enquiries & Projects</Text>
  {requests.length===0?card(<><Text style={s.serviceTitle}>No enquiries yet</Text><Text style={s.muted}>Your quotation and service requests will appear here after submission.</Text><Button title="Request quotation" onPress={()=>setTab('Quote')}/></>):requests.map((r,i)=>card(<View key={i}><Text style={s.serviceTitle}>{r.kind}</Text><Text style={s.muted}>{r.name} · {r.phone}</Text><Text style={s.muted}>{r.city} {r.capacity}</Text><Text style={s.status}>{r.status}</Text></View>))}
  <Text style={s.muted}>Live project tracking requires a connected company backend.</Text>
 </ScrollView>;
 const messages=()=> <View style={s.content}>{header()}<Text style={s.section}>Messages</Text>{card(<><Text style={s.serviceTitle}>KALSI Support</Text><Text style={s.muted}>Messaging preview. Connect a chat service/backend to enable team communication.</Text>{chat.map((m,i)=><Text key={i} style={s.chatLine}>You: {m}</Text>)}<TextInput value={message} onChangeText={setMessage} placeholder="Write a message" style={s.input}/><Button title="Add message (demo)" onPress={()=>{if(message.trim()){setChat([...chat,message]);setMessage('')}}}/></>)}</View>;
 const profile=()=> <ScrollView contentContainerStyle={s.content}>{header()}<Text style={s.section}>Profile & Information</Text>{card(<><Text style={s.serviceTitle}>KALSI Renewables</Text><Text style={s.muted}>Powering a Sustainable Future</Text><Text style={s.body}>Explore solar installations, request quotations and track your enquiries from this app.</Text><Text style={s.label}>Company contact</Text><Text style={s.body}>Add and verify your official business phone, email and address before publishing.</Text><Button outline title={admin?'Hide admin preview':'Admin dashboard preview'} onPress={()=>setAdmin(!admin)}/>{admin&&<View style={s.admin}><Text style={s.serviceTitle}>Admin Dashboard (local preview)</Text><Text style={s.body}>Total enquiries on this device: {requests.length}</Text><Text style={s.body}>Products, payments, customer accounts and staff permissions need backend setup.</Text></View>}</>)}</ScrollView>;
 const screens={Home:home,Quote:quote,Bookings:bookings,Messages:messages,Profile:profile};
 return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor={NAVY}/>{screens[tab]()}<View style={s.nav}>{[['Home','⌂'],['Quote','＋'],['Bookings','▣'],['Messages','✉'],['Profile','●']].map(([t,ic])=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={s.navItem}><Text style={[s.navIcon,tab===t&&{color:YELLOW}]}>{ic}</Text><Text style={[s.navText,tab===t&&{color:YELLOW,fontWeight:'700'}]}>{t}</Text></TouchableOpacity>)}</View></SafeAreaView>;
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:BG},content:{padding:16,paddingBottom:28},header:{backgroundColor:NAVY,borderRadius:18,padding:20,marginBottom:16},brand:{fontSize:30,fontWeight:'900',color:'white',letterSpacing:2},subbrand:{color:YELLOW,fontSize:14,fontWeight:'800',letterSpacing:4},tag:{color:'#DCE8F5',marginTop:8,fontSize:12},
 hero:{backgroundColor:BLUE,borderRadius:18,padding:20,marginBottom:20},heroSmall:{color:YELLOW,fontSize:10,fontWeight:'800',letterSpacing:1},heroTitle:{fontSize:28,fontWeight:'900',color:'white',marginTop:10},heroText:{color:'white',fontSize:14,lineHeight:21,marginVertical:12},
 section:{fontSize:21,fontWeight:'900',color:NAVY,marginVertical:12},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},service:{width:'48%',backgroundColor:'white',padding:14,borderRadius:14,marginBottom:12,minHeight:142,borderWidth:1,borderColor:'#E4EAF1'},icon:{fontSize:25,marginBottom:8},serviceTitle:{fontSize:15,fontWeight:'800',color:NAVY,marginBottom:6},muted:{fontSize:12,color:'#5D6B7A',lineHeight:18},notice:{backgroundColor:'#FFF7D8',padding:16,borderRadius:15,marginTop:8},noticeTitle:{fontSize:17,fontWeight:'800',color:NAVY,marginBottom:6},foot:{textAlign:'center',color:'#718096',fontSize:11,margin:20},
 card:{backgroundColor:'white',padding:16,borderRadius:16,marginBottom:14,borderWidth:1,borderColor:'#E4EAF1'},label:{fontSize:13,fontWeight:'700',color:NAVY,marginTop:12,marginBottom:6},input:{borderWidth:1,borderColor:'#D5DEE8',borderRadius:10,paddingHorizontal:12,paddingVertical:11,fontSize:14,backgroundColor:'white',color:'#14283D'},btn:{backgroundColor:YELLOW,padding:14,borderRadius:11,alignItems:'center',marginTop:14,minHeight:48,justifyContent:'center'},btnText:{color:NAVY,fontWeight:'900',fontSize:14},outline:{backgroundColor:'white',borderWidth:1,borderColor:NAVY},choice:{padding:11,borderWidth:1,borderColor:'#DCE3EB',borderRadius:9,marginTop:7},choiceActive:{borderColor:BLUE,backgroundColor:'#EAF2FB'},status:{color:GREEN,fontWeight:'800',marginTop:10},body:{color:'#35485C',fontSize:14,lineHeight:21,marginTop:8},nav:{flexDirection:'row',backgroundColor:NAVY,paddingVertical:9,paddingBottom:12,justifyContent:'space-around'},navItem:{alignItems:'center',minWidth:55,minHeight:44,justifyContent:'center'},navIcon:{fontSize:19,color:'white'},navText:{fontSize:10,color:'#D8E3EF',marginTop:2},chatLine:{padding:9,backgroundColor:'#EAF2FB',borderRadius:9,marginTop:8,color:NAVY},admin:{marginTop:16,padding:12,backgroundColor:'#F3F6FA',borderRadius:10}
});
